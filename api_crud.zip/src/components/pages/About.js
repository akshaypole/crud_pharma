import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const About = () => {

  const [medicines_info, setUser] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("https://608192fc73292b0017cddd24.mockapi.io/medicines_info/");
    setUser(result.data.reverse());
  };

  const deleteUser = async id => {
    await axios.delete(`https://608192fc73292b0017cddd24.mockapi.io/medicines_info/${id}`);
    loadUsers();
  };
  return (
    <div className="container">
      <div className="py-4">
      <div class = "row">
          <div class ="col-sm-6">
            <h1>Medicine Information</h1>
          </div>
          <div class ="col-sm-6">
            <Link className="btn btn-primary mr-2" to="/medicines/add_meds">Add Medicine</Link>
          </div>
        </div>
        <table class="table border shadow">
          <thead class="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Manufacturer Name</th>
              <th scope="col">Stock</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {medicines_info.map((meds, index) => (
              <tr>
                <th scope="row">{index + 1}</th>
                <td>{meds.name}</td>
                <td>{meds.manufacturer}</td>
                <td>{meds.stock}</td>
                <td>
                  <Link class="btn btn-primary mr-2" to={`/medicines/${meds.id}`}>
                    View
                  </Link>
                  <Link
                    class="btn btn-outline-primary mr-2"
                    to={`/medicines/edit/${meds.id}`}
                  >
                    Edit
                  </Link>
                  <Link
                    class="btn btn-danger"
                    onClick={() => deleteUser(meds.id)}
                  >
                    Delete
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
      </div>

    </div>
  );
};

export default About;
