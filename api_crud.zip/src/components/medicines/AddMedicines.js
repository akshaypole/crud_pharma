import React, { useState } from "react";
import axios from 'axios'
import { useHistory } from "react-router-dom";


const AddMedicines = () =>{


    let history = useHistory();
  const [meds, setUser] = useState({
    name: "",
    manufacturer: "",
    stock: "",  
    price: "",
    discount: ""
  });

  const { name, manufacturer, stock, price, discount } = meds;
  const onInputChange = e => {
    setUser({ ...meds, [e.target.name]: e.target.value });
  };

  const onSubmit = async e => {
    e.preventDefault();
    await axios.post("https://608192fc73292b0017cddd24.mockapi.io/medicines_info/", meds);
    history.push("/about");
  };
  return (
    <div className="container">
      <div className="w-75 mx-auto shadow p-5">
        <h2 className="text-center mb-4">Add A Medicine</h2>
        <form onSubmit={e => onSubmit(e)}>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Medicine Name"
              name="name"
              value={name}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Manufacturer Name"
              name="manufacturer"
              value={manufacturer}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Stock"
              name="stock"
              value={stock}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Price"
              name="price"
              value={price}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter dicount percentage"
              name="discount"
              value={discount}
              onChange={e => onInputChange(e)}
            />
          </div>
          <button className="btn btn-primary btn-block">Add Medicine</button>
        </form>
      </div>
    </div>
  );



};

export default AddMedicines;