import React, { useState, useEffect } from "react";
import axios from "axios";
import { useHistory, useParams } from "react-router-dom";

const EditMedicines = () =>{

    let history = useHistory();
  const { id } = useParams();
  const [meds, setUser] = useState({
    name: "",
    manufacturer: "",
    stock: "",
    price: "",
    discount: ""
  });

  const { name, manufacturer, stock, price, discount } = meds;
  const onInputChange = e => {
    setUser({ ...meds, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    loadUser();
  }, []);

  const onSubmit = async e => {
    e.preventDefault();
    await axios.put(`https://608192fc73292b0017cddd24.mockapi.io/medicines_info/${id}`, meds);
    history.push("/about");
  };

  const loadUser = async () => {
    const result = await axios.get(`https://608192fc73292b0017cddd24.mockapi.io/medicines_info/${id}`);
    setUser(result.data);
  };
  return (
    <div className="container">
      <div className="w-75 mx-auto shadow p-5">
        <h2 className="text-center mb-4">Edit Medicine Info.</h2>
        <form onSubmit={e => onSubmit(e)}>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Name"
              name="name"
              value={name}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Manufacturer"
              name="manufacturer"
              value={manufacturer}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Stock"
              name="stock"
              value={stock}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Price"
              name="price"
              value={price}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-lg"
              placeholder="Enter Discount"
              name="discount"
              value={discount}
              onChange={e => onInputChange(e)}
            />
          </div>
          <button className="btn btn-warning btn-block">Update Medicine</button>
        </form>
      </div>
    </div>
  );

};

export default EditMedicines;