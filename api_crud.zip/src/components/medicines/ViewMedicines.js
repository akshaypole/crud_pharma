import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import axios from "axios";

const ViewMedicines = () =>{

    const [meds, setUser] = useState({
        name: "",
        manufacturer: "",
        stock: "",
        price: "",
        discount:""
      });
      const { id } = useParams();
      useEffect(() => {
        loadUser();
      }, []);
      const loadUser = async () => {
        const res = await axios.get(`https://608192fc73292b0017cddd24.mockapi.io/medicines_info/${id}`);
        setUser(res.data);
      };
      return (
        <div className="container py-4">
          <Link className="btn btn-primary" to="/about">
            Back to Medicines Info.
          </Link>
          <h1 className="display-4">Medicine Id: {id}</h1>
          <hr />
          <ul className="list-group w-50">
            <li className="list-group-item">Name: {meds.name}</li>
            <li className="list-group-item">Manufacturer Name: {meds.manufacturer}</li>
            <li className="list-group-item">Stock: {meds.stock}</li>
            <li className="list-group-item">Price: {meds.price}</li>
            <li className="list-group-item">Discount: {meds.discount}</li>
          </ul>
        </div>
      );

};

export default ViewMedicines;